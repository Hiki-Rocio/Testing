# Challenger
ChallengerFinal_CursoTesting
![Miniatura](https://user-images.githubusercontent.com/57378007/222938733-6e3d0262-7387-4f81-a0ef-c0410bded9cf.jpg)



PRESTA ATENCIÓN A CADA PUNTO DE ESTE DOCUMENTO 

NO HABRÁ AYUDA SOBRE CÓMO REALIZAR LO QUE SE PIDE EN EL CHALLENGE

Puntos a Seguir:

1) Utilizar las 4 horas de clase para trabajar como equipo, el link de zoom permanecerá abierto durante todo el challenge
2) Los mentores estarán presentes para tomar lista y disipar dudas sobre el contenido del archivo de las instrucciones del challenge
3) No se contestarán dudas sobre las Historias de Usuario  o Criterios de Aceptación que el cliente proporcionó al equipo de Dev
4) No habrá un líder definido por lo tanto cada uno de los integrante del equipo será el responsable de llevar una daily ( opcional: Pueden invitar a un mentor o  una coordinadora para que los acompañe en su daily)
Deberán Marcar la Asistencia , se les indicará en que tarea deberan marcarla.
5) Se leerán las instrucciones para el challenger
6) Se proporcionará una liga del repositorio GIT con toda la documentación necesaria para iniciar
7) Se proporcionará el sistema a testear al 3er dia de iniciado el Challenge, esto con el fin de que los primeros 3 dias puedan LEER COMPLETAMENTE LA DOCUMENTACION, organizarse , preparar Jira , diseñar todos los casos de prueba y haber investigado un homebanking de un banco de su preferencia para darse una idea.

